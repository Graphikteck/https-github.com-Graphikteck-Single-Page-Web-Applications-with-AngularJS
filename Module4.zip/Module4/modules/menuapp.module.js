(function() {
    'use strict';

    angular.module('MenuApp', ['data', 'ui.router']).constant('ApiBasePath', "https://davids-restaurant.herokuapp.com");
})();
